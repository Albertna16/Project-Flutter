package com.example.listview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
