package com.example.containeranddecorationcontainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
