package com.example.image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
