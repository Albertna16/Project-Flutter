package com.example.statefullwidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
