package com.example.expandedandflexible

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
