package com.example.textfield

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
